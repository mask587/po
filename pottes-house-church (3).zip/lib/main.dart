import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyCyiBMJhKk3MpzQvUMeMDCsnP3QkvS221k",
      authDomain: "church-prayer-app.firebaseapp.com",
      projectId: "church-prayer-app",
      storageBucket: "church-prayer-app.appspot.com", // ✅ FIXED
      messagingSenderId: "1044425262008",
      appId: "1:1044425262008:web:fc6762aa2158de5e0d054d",
    ),
  );

  runApp(ChurchApp());
}

Color darkBlue = Color(0xFF001F54);

class ChurchApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Potter's House Church Trichy",
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
      theme: ThemeData(
        primaryColor: darkBlue,
        textTheme: GoogleFonts.poppinsTextTheme(),
        appBarTheme: AppBarTheme(
          backgroundColor: darkBlue,
          iconTheme: IconThemeData(color: Colors.white),
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
        ),
      ),
    );
  }
}

/*---------------------------------------------------
                    SPLASH SCREEN
---------------------------------------------------*/
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> fadeAnim;
  late Animation<double> scaleAnim;
  late Animation<double> textAnim;
  late Animation<double> rotateAnim;

  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(seconds: 5));

    fadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: controller, curve: Interval(0.0, 0.5)));

    scaleAnim = Tween<double>(begin: 0.7, end: 1.0).animate(
        CurvedAnimation(parent: controller, curve: Curves.easeOutBack));

    textAnim = Tween<double>(begin: 40, end: 0).animate(
        CurvedAnimation(parent: controller, curve: Interval(0.5, 1.0)));

    rotateAnim = Tween<double>(begin: 0, end: 2 * 3.1416).animate(
        CurvedAnimation(parent: controller, curve: Curves.linear)); // rotate

    controller.forward();

    // Navigate after 5 seconds
    Timer(Duration(seconds: 5), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => Dashboard()),
      );
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedContainer(
        duration: Duration(seconds: 5),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xff170ec8),
              Color(0xff6307a6),
              Color(0xff9c058f),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: controller,
            builder: (context, child) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Opacity(
                    opacity: fadeAnim.value,
                    child: Transform.rotate(
                      angle: rotateAnim.value, // <-- rotation added
                      child: Transform.scale(
                        scale: scaleAnim.value,
                        child: Container(
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white.withOpacity(0.5),
                                blurRadius: 30,
                                spreadRadius: 2,
                              )
                            ],
                          ),
                          child: Image.asset("assets/images/logo.jpg",
                              height: 140),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Transform.translate(
                    offset: Offset(0, textAnim.value),
                    child: Opacity(
                      opacity: fadeAnim.value,
                      child: Text(
                        "POTTER'S HOUSE CHURCH TRICHY",
                        style: TextStyle(
                            fontSize: 23,
                            fontWeight: FontWeight.bold,
                            color: Color(0xffc2db21),
                            letterSpacing: 1.5),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

/*---------------------------------------------------
                    DASHBOARD
---------------------------------------------------*/
class Dashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff48479d),
      appBar: AppBar(
        title: Text("🏠 Dashboard", style: TextStyle(color: Colors.white)),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              children: [
                _tile(context, Icons.info, "About Us", AboutUsPage()),
                _tile(context, Icons.call, "Contact Us", ContactPage()),
                _tile(context, Icons.people, "Ministries", MinistryPage()),
                _tile(context, Icons.photo, "Church Images", ChurchImages()),
                _tile(context, Icons.check, "Notification", CheckInPage()),
                _tile(context, Icons.book, "Daily Bible", DailyBiblePage()),
                _tile(context, Icons.book, "Special Events", SpecialEvents()),
                _tile(context, Icons.favorite, "Prayer Requests",
                    PrayerRequestPage()),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String text, Widget page) {
    return InkWell(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (_) => page));
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // 🌈 COLORFUL ROUND ICON (NO WHITE BOX)
          Container(
            height: 80,
            width: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  Colors.pinkAccent,
                  Colors.deepPurpleAccent,
                  Colors.blueAccent,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 6,
                  offset: Offset(0, 4),
                )
              ],
            ),
            child: Icon(
              icon,
              size: 36,
              color: Colors.white,
            ),
          ),

          SizedBox(height: 10),

          Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

/*---------------------------------------------------
                DAILY BIBLE PAGE (NEW)
---------------------------------------------------*/

class DailyBiblePage extends StatefulWidget {
  @override
  _DailyBiblePageState createState() => _DailyBiblePageState();
}

class _DailyBiblePageState extends State<DailyBiblePage> {
  List<String> verses = [
    "“The Lord is my shepherd; I shall not want.” — Psalm 23:1",
    "“I can do all things through Christ who strengthens me.” — Philippians 4:13",
    "“Trust in the Lord with all your heart.” — Proverbs 3:5",
    "“Be still and know that I am God.” — Psalm 46:10",
    "“The Lord is my light and my salvation.” — Psalm 27:1",
    "“The joy of the Lord is your strength.” — Nehemiah 8:10",
    "“Cast all your anxiety on Him because He cares for you.” — 1 Peter 5:7",
    "“With God all things are possible.” — Matthew 19:26",
    "“The Lord will fight for you; you need only be still.” — Exodus 14:14",
    "“The Lord bless you and keep you.” — Numbers 6:24",
    "“The Lord is good; His love endures forever.” — Psalm 136:1",
    "“Your word is a lamp to my feet.” — Psalm 119:105",
    "“God is our refuge and strength.” — Psalm 46:1",
    "“My grace is sufficient for you.” — 2 Corinthians 12:9",
    "“The righteous shall live by faith.” — Romans 1:17",
    "“The Lord is near to all who call on Him.” — Psalm 145:18",
    "“Do not fear, for I am with you.” — Isaiah 41:10",
    "“The Lord is faithful to all His promises.” — Psalm 145:13",
    "“Peace I leave with you; My peace I give you.” — John 14:27",
    "“We love because He first loved us.” — 1 John 4:19",
    "“Delight yourself in the Lord.” — Psalm 37:4",
    "“The Lord is my helper; I will not fear.” — Hebrews 13:6",
    "“Rejoice in the Lord always.” — Philippians 4:4",
    "“He restores my soul.” — Psalm 23:3",
    "“God is love.” — 1 John 4:8",
    "“The Lord is gracious and compassionate.” — Psalm 145:8",
    "“The Lord watches over you.” — Psalm 121:5",
    "“Commit your way to the Lord.” — Psalm 37:5",
    "“The fear of the Lord is the beginning of wisdom.” — Proverbs 9:10",
    "“The Lord will perfect that which concerns me.” — Psalm 138:8",
    "“The name of the Lord is a strong tower.” — Proverbs 18:10",
    "“The Lord is compassionate and slow to anger.” — Psalm 103:8",
    "“Bless the Lord, O my soul.” — Psalm 103:1",
    "“Your faith has made you well.” — Mark 5:34",
    "“We walk by faith, not by sight.” — 2 Corinthians 5:7",
    "“The battle is the Lord’s.” — 1 Samuel 17:47",
    "“He heals the brokenhearted.” — Psalm 147:3",
    "“If God is for us, who can be against us?” — Romans 8:31",
    "“Let everything that has breath praise the Lord.” — Psalm 150:6",
    "“Call to Me and I will answer you.” — Jeremiah 33:3",
    "“My help comes from the Lord.” — Psalm 121:2",
    "“The Lord is close to the brokenhearted.” — Psalm 34:18",
    "“In God I trust; I will not be afraid.” — Psalm 56:4",
    "“The Lord surrounds His people.” — Psalm 125:2",
    "“Blessed are the pure in heart.” — Matthew 5:8",
    "“He who promised is faithful.” — Hebrews 10:23",
    "“The Lord is my strength and my shield.” — Psalm 28:7",
    "“I will fear no evil, for You are with me.” — Psalm 23:4",
    "“The Lord stands with me and strengthens me.” — 2 Timothy 4:17",
    "“The Lord gives wisdom.” — Proverbs 2:6",
    "“Surely goodness and mercy shall follow me.” — Psalm 23:6",
    "“Clothe yourselves with compassion, kindness, humility.” — Colossians 3:12",
    "“Your faithfulness continues through all generations.” — Psalm 119:90",
    "“Be strong in the Lord.” — Ephesians 6:10",
    "“Let the peace of Christ rule in your hearts.” — Colossians 3:15",
    "“He will never leave you nor forsake you.” — Deuteronomy 31:6",
    "“The Lord is good to those who hope in Him.” — Lamentations 3:25",
    "“The Lord knows the way of the righteous.” — Psalm 1:6",
    "“Ask and it will be given to you.” — Matthew 7:7",
    "“The Lord gives strength to His people.” — Psalm 29:11",
    "“Do everything in love.” — 1 Corinthians 16:14",
    "“The word of the Lord endures forever.” — 1 Peter 1:25",
    "“Let your light shine before others.” — Matthew 5:16",
    "“My presence will go with you.” — Exodus 33:14",
    "“He will give you the desires of your heart.” — Psalm 37:4",
    "“As for me and my house, we will serve the Lord.” — Joshua 24:15",
    "“Be strong and courageous.” — Joshua 1:9",
    "“A joyful heart is good medicine.” — Proverbs 17:22",
    "“Be kind and compassionate to one another.” — Ephesians 4:32",
    "“Faith comes by hearing the word of God.” — Romans 10:17",
    "“The Lord will keep you from all harm.” — Psalm 121:7",
    "“Those who hope in the Lord will renew their strength.” — Isaiah 40:31",
    "“Blessed are the peacemakers.” — Matthew 5:9",
    "“For where your treasure is, there your heart will be also.” — Matthew 6:21",
    "“Be faithful unto death, and I will give you a crown of life.” — Revelation 2:10",
    "“The Lord lifts up those who are bowed down.” — Psalm 146:8",
    "“Those who seek the Lord lack no good thing.” — Psalm 34:10",
    "“Your Father knows what you need before you ask Him.” — Matthew 6:8",
    "“My cup overflows.” — Psalm 23:5",
    "“The Lord reigns forever.” — Psalm 146:10",
    "“The Lord is my rock, my fortress, and my deliverer.” — Psalm 18:2",
    "“Pray without ceasing.” — 1 Thessalonians 5:17",
    "“The Lord will be your everlasting light.” — Isaiah 60:19",
    "“Be merciful, just as your Father is merciful.” — Luke 6:36",
    "“He gives strength to the weary.” — Isaiah 40:29",
    "“The Lord is my portion.” — Lamentations 3:24",
    "“The Lord is righteous in all His ways.” — Psalm 145:17",
    "“I will praise You with all my heart.” — Psalm 138:1",
    "“Blessed are those who mourn, for they will be comforted.” — Matthew 5:4",
    "“For God so loved the world.” — John 3:16",
    "“The Lord is slow to anger and great in power.” — Nahum 1:3",
    "“Let us not grow weary in doing good.” — Galatians 6:9",
    "“The Lord is my deliverer.” — 2 Samuel 22:2",
    "“In quietness and trust is your strength.” — Isaiah 30:15",
    "“He will make your paths straight.” — Proverbs 3:6",
    "“I will never forget Your precepts.” — Psalm 119:93",
    "“The Lord hears when I call to Him.” — Psalm 4:3",
    "“Let the weak say, ‘I am strong.’” — Joel 3:10",
    "“The Lord is faithful; He will strengthen you.” — 2 Thessalonians 3:3",
    "“His mercies are new every morning.” — Lamentations 3:23",
    "“The Lord is my helper.” — Hebrews 13:6",
    "“The Lord blesses His people with peace.” — Psalm 29:11",
    "“The eternal God is your refuge.” — Deuteronomy 33:27",
    "“He crowns the humble with salvation.” — Psalm 149:4",
    "“The Lord will answer you when you call.” — Psalm 20:6",
    "“Blessed are those who hunger for righteousness.” — Matthew 5:6",
    "“The Lord upholds all who fall.” — Psalm 145:14",
    "“Your Redeemer lives.” — Job 19:25",
    "“His love endures through all generations.” — Psalm 100:5",
    "“The Lord is my defense.” — Psalm 94:22",
    "“He gives rest to the weary.” — Matthew 11:28",
    "“The Lord is faithful in all He does.” — Psalm 33:4",
    "“Let your heart take courage.” — Psalm 27:14",
    "“The Lord is upright.” — Psalm 92:15",
    "“Whatever you do, do it for the glory of God.” — 1 Corinthians 10:31",
    "“His peace will guard your hearts.” — Philippians 4:7",
    "“The Lord heals your wounds.” — Jeremiah 30:17",
    "“The light shines in the darkness.” — John 1:5",
    "“He gives grace to the humble.” — James 4:6",
    "“The Lord watches over your life.” — Psalm 121:7-8",
    "“Fear not, little flock.” — Luke 12:32",
    "“He will strengthen your heart.” — Psalm 31:24",
    "“The Lord is righteous and loves justice.” — Psalm 11:7",
    "“Be transformed by the renewing of your mind.” — Romans 12:2",
    "“He will give you rest.” — Exodus 33:14",
    "“My peace will be with you.” — 2 Thessalonians 3:16",
    "“He gathers the lambs in His arms.” — Isaiah 40:11",
    "“The Lord sustains me.” — Psalm 3:5",
    "“He is my refuge and my fortress.” — Psalm 91:2",
    "“Blessed are the merciful.” — Matthew 5:7",
    "“The Lord is the strength of my life.” — Psalm 27:1",
    "“His word is trustworthy.” — Psalm 93:5",
    "“He will uphold you with His righteous hand.” — Isaiah 41:10",
    "“The Lord loves the righteous.” — Psalm 146:8",
    "“I have loved you with an everlasting love.” — Jeremiah 31:3",
    "“He renews your youth like the eagle’s.” — Psalm 103:5",
    "“Those who trust in the Lord are blessed.” — Jeremiah 17:7",
    "“He will restore you.” — 1 Peter 5:10",
    "“The Lord will deliver you.” — Psalm 34:7",
    "“His truth endures to all generations.” — Psalm 100:5",
    "“He is my shield.” — Psalm 18:30",
    "“The Lord surrounds His people.” — Psalm 125:2",
    "“Rejoice in hope.” — Romans 12:12",
    "“Be faithful in prayer.” — Romans 12:12",
    "“The Lord works righteousness and justice.” — Psalm 103:6",
    "“He leads me beside still waters.” — Psalm 23:2",
    "“Do not let your hearts be troubled.” — John 14:1",
    "“We love because He first loved us.” — 1 John 4:19",
    "“His faithfulness is a shield.” — Psalm 91:4",
    "“He will guide you always.” — Isaiah 58:11",
    "“He will keep you in perfect peace.” — Isaiah 26:3",
    "“God is our refuge.” — Psalm 62:8",
    "“The Lord is near.” — Psalm 34:18",
    "“Blessed is the one who trusts in Him.” — Psalm 84:12",
    "“He forgives all your sins.” — Psalm 103:3",
    "“God is light.” — 1 John 1:5",
    "“Let the peace of Christ rule in your hearts.” — Colossians 3:15",
    "“His mercy is great.” — 2 Samuel 24:14",
    "“He gives strength to His people.” — Psalm 29:11",
    "“The righteous cry out, and the Lord hears.” — Psalm 34:17",
    "“The Lord knows those who are His.” — 2 Timothy 2:19",
    "“He will calm all your fears.” — Zephaniah 3:17",
    "“God is our help.” — Psalm 33:20",
    "“He guides the humble.” — Psalm 25:9",
    "“Blessed are the meek.” — Matthew 5:5",
    "“The Lord gives wisdom.” — Proverbs 2:6",
    "“His plans are to prosper you.” — Jeremiah 29:11",
    "“The Lord strengthens the weak.” — Psalm 89:13",
    "“The Lord is your keeper.” — Psalm 121:5",
    "“Rejoice always.” — 1 Thessalonians 5:16",
    "“The Lord is good and upright.” — Psalm 25:8",
    "“He comforts us in all our troubles.” — 2 Corinthians 1:4",
    "“The Lord detests wickedness.” — Psalm 5:4",
    "“Your faith has saved you.” — Luke 7:50",
    "“He will protect you from danger.” — Psalm 91:3",
    "“The Lord is mighty in battle.” — Psalm 24:8",
    "“Be strong and take heart.” — Psalm 31:24",
    "“The Lord does not change.” — Malachi 3:6",
    "“He gives rest to His beloved.” — Psalm 127:2",
    "“The Lord is gracious.” — Psalm 116:5",
    "“He gives joy to the righteous.” — Psalm 97:11",
    "“The Lord is a God of justice.” — Isaiah 30:18",
    "“He will wipe every tear.” — Revelation 21:4",
    "“The Lord is good to all.” — Psalm 145:9",
    "“He is slow to anger and abounding in love.” — Psalm 103:8",
    "“The Lord hears the needy.” — Psalm 69:33",
    "“He will never forsake His inheritance.” — Psalm 94:14",
    "“The Lord gives victory.” — Proverbs 21:31",
    "“He will rescue you from trouble.” — Psalm 50:15",
    "“His love is better than life.” — Psalm 63:3",
    "“God is able.” — 2 Corinthians 9:8",
    "“He rewards those who seek Him.” — Hebrews 11:6",
    "“The Lord is righteous.” — Psalm 129:4",
    "“He gives His angels charge over you.” — Psalm 91:11",
    "“The Lord is close to all who call on Him.” — Psalm 145:18",
    "“His ways are perfect.” — Psalm 18:30",
    "“The Lord will keep you strong.” — 1 Corinthians 1:8",
    "“He renews your strength.” — Isaiah 40:31",
    "“The Lord is your shade.” — Psalm 121:5",
    "“His love endures forever.” — Psalm 118:1",
    "“The Lord will fulfill His purpose for me.” — Psalm 138:8",
    "“He will give you the victory.” — 1 Corinthians 15:57",
    "“The Lord is trustworthy.” — Psalm 145:13",
    "“He quiets you with His love.” — Zephaniah 3:17",
    "“The Lord is your everlasting strength.” — Isaiah 26:4",
    "“He gives power to the faint.” — Isaiah 40:29",
    "“My God will meet all your needs.” — Philippians 4:19",
    "“The Lord will guard your going out and coming in.” — Psalm 121:8",
    "“He alone is my salvation.” — Psalm 62:2",
    "“The Lord is on my side; I will not fear.” — Psalm 118:6",
    "“He is the Rock; His works are perfect.” — Deuteronomy 32:4",
    "“The Lord delights in His people.” — Psalm 149:4",
    "“He gives songs in the night.” — Job 35:10",
    "“The Lord is my helper.” — Psalm 118:7",
    "“He restores health to you.” — Jeremiah 30:17",
    "“God is our strong tower.” — Proverbs 18:10",
    "“The Lord blesses the righteous.” — Psalm 5:12",
    "“He gives you peace at all times.” — 2 Thessalonians 3:16",
    "“The Lord is my salvation and my honor.” — Psalm 62:7",
    "“His compassions never fail.” — Lamentations 3:22",
    "“He will cover you with His feathers.” — Psalm 91:4",
    "“The Lord is good to all who call on Him.” — Psalm 86:5",
    "“His strength is made perfect in weakness.” — 2 Corinthians 12:9",
    "“He preserves the faithful.” — Psalm 31:23",
    "“The Lord is exalted.” — Psalm 113:4",
    "“He will not let you fall.” — Psalm 121:3",
    "“The Lord loves justice.” — Psalm 37:28",
    "“He provides food for those who fear Him.” — Psalm 111:5",
    "“The Lord lifts the needy from the ash heap.” — Psalm 113:7",
    "“He will show you the path of life.” — Psalm 16:11",
    "“The Lord is my strength.” — Psalm 118:14",
    "“He is my refuge in times of trouble.” — Nahum 1:7",
    "“The Lord shall fight for you.” — Exodus 14:14",
    "“He knows those who trust in Him.” — Nahum 1:7",
    "“The Lord will give grace and glory.” — Psalm 84:11",
    "“He will not forsake His saints.” — Psalm 37:28",
    "“God is my defense.” — Psalm 59:9",
    "“He is a shield to those who take refuge in Him.” — Proverbs 30:5",
    "“The Lord upholds the righteous.” — Psalm 37:17",
    "“He will instruct you.” — Psalm 32:8",
    "“The Lord is your protector.” — Psalm 121:5",
    "“He will be your guide even to the end.” — Psalm 48:14",
    "“The Lord remembers His covenant forever.” — Psalm 105:8",
    "“He sets the prisoners free.” — Psalm 146:7",
    "“The Lord raises those who are bowed down.” — Psalm 146:8",
    "“He makes firm the steps of the one who delights in Him.” — Psalm 37:23",
    "“The Lord is your keeper.” — Psalm 121:5",
    "“He will be with you wherever you go.” — Joshua 1:9",
    "“The Lord surrounds His people forever.” — Psalm 125:2",
    "“He will bless the work of your hands.” — Deuteronomy 28:12",
    "“The Lord will strengthen you.” — Isaiah 41:10",
    "“He heals the brokenhearted.” — Psalm 147:3",
    "“His love never fails.” — 1 Corinthians 13:8",
    "“He will lift you up.” — James 4:10",
    "“The Lord will uphold you.” — Psalm 145:14",
    "“He will renew your life.” — Ruth 4:15",
    "“The Lord is a refuge for the oppressed.” — Psalm 9:9",
    "“He fills your life with good things.” — Psalm 103:5",
    "“The Lord will answer your prayers.” — Psalm 65:2",
    "“He crowns you with love.” — Psalm 103:4",
    "“The Lord gives rest.” — Exodus 33:14",
    "“He will show you His salvation.” — Psalm 91:16",
    "“God is able to bless you abundantly.” — 2 Corinthians 9:8",
    "“He will keep you from falling.” — Jude 1:24",
    "“The Lord is merciful and gracious.” — Psalm 103:8",
    "“He gives strength to the weary.” — Isaiah 40:29",
    "“The Lord is my refuge.” — Psalm 91:2",
    "“He will guide you continually.” — Isaiah 58:11",
    "“The Lord watches over the righteous.” — Psalm 34:15",
    "“He gives wisdom generously.” — James 1:5",
    "“The Lord is faithful.” — 2 Thessalonians 3:3",
    "“He will keep you safe.” — Proverbs 1:33",
    "“The Lord answers when you call.” — Psalm 138:3",
    "“He gives you peace.” — John 14:27",
    "“The Lord delights in your way.” — Psalm 37:23",
    "“He forgives all your sins.” — Psalm 103:3",
    "“The Lord is your refuge in times of distress.” — Jeremiah 16:19",
    "“He gives grace to the humble.” — 1 Peter 5:5",
    "“The Lord reigns forever.” — Psalm 146:10",
    "“He will never fail you.” — Joshua 1:5",
    "“The Lord is slow to anger.” — Psalm 103:8",
    "“He carries you.” — Isaiah 46:4",
    "“The Lord will deliver you.” — Psalm 34:17",
    "“He is your shield.” — Psalm 3:3",
    "“The Lord hears your cry.” — Psalm 40:1",
    "“He will strengthen your heart.” — Psalm 27:14",
    "“The Lord is gracious to the humble.” — Isaiah 57:15",
    "“He gives you hope and a future.” — Jeremiah 29:11",
    "“The Lord will bless you and keep you.” — Numbers 6:24",
    "“He is the lifter of your head.” — Psalm 3:3",
    "“The Lord watches over you.” — Psalm 121:5",
    "“He will satisfy your needs.” — Isaiah 58:11",
    "“The Lord grants peace.” — Psalm 147:14",
    "“He will restore your fortunes.” — Jeremiah 30:18",
    "“God is our refuge and strength.” — Psalm 46:1",
    "“He will save you.” — Isaiah 35:4",
    "“The Lord is good to those who trust in Him.” — Nahum 1:7",
    "“He is with you in trouble.” — Psalm 91:15",
    "“The Lord is your confidence.” — Proverbs 3:26",
    "“He is faithful to all His promises.” — Psalm 145:13",
    "“The Lord will provide.” — Genesis 22:14",
    "“He gives you victory.” — Psalm 44:7",
    "“God is not a man that He should lie.” — Numbers 23:19",
    "“He renews your strength like the eagle.” — Isaiah 40:31",
    "“The Lord keeps you from evil.” — Psalm 121:7",
    "“He is your refuge in times of trouble.” — Psalm 9:9",
    "“The Lord sustains the righteous.” — Psalm 55:22",
    "“He surrounds you with love.” — Psalm 32:10",
    "“The Lord will guard your heart and mind.” — Philippians 4:7",
    "“He leads you beside still waters.” — Psalm 23:2",
    "“The Lord is my stronghold.” — Psalm 27:1",
    "“He will give you rest.” — Matthew 11:28",
    "“God is love.” — 1 John 4:8",
    "“He will be with you always.” — Matthew 28:20",
    "“The Lord is your helper.” — Psalm 54:4",
    "“He gives you the desires of your heart.” — Psalm 37:4",
    "“The Lord goes before you.” — Deuteronomy 31:8",
    "“He will wipe every tear from your eyes.” — Revelation 21:4",
    "“The Lord is the strength of His people.” — Psalm 28:8",
    "“He will keep you in perfect peace.” — Isaiah 26:3",
    "“God is our rock.” — Psalm 18:2",
    "“He will not withhold good from you.” — Psalm 84:11",
    "“The Lord is your light.” — Psalm 27:1",
    "“He is faithful and just to forgive.” — 1 John 1:9",
    "“The Lord is my portion.” — Psalm 73:26",
    "“He gives peace like a river.” — Isaiah 48:18",
    "“The Lord is a shield around you.” — Psalm 3:3",
    "“He will guide your steps.” — Proverbs 3:6",
    "“God is for us.” — Romans 8:31",
    "“He will rescue you.” — Psalm 34:7",
    "“The Lord is great and greatly to be praised.” — Psalm 145:3",
    "“He is the God who sees you.” — Genesis 16:13",
    "“The Lord is upright.” — Psalm 92:15",
    "“He carries your burdens.” — Psalm 55:22",
    "“The Lord directs your steps.” — Proverbs 16:9",
    "“He will give you joy.” — Psalm 16:11",
    "“The Lord is faithful forever.” — Psalm 146:6",
    "“He will not forsake you.” — Deuteronomy 31:6",
    "“The Lord surrounds you with favor.” — Psalm 5:12",
    "“He knows the plans He has for you.” — Jeremiah 29:11",
    "“The Lord gives victory.” — 1 Corinthians 15:57",
    "“He comforts all who mourn.” — Isaiah 61:2",
    "“The Lord is near to the brokenhearted.” — Psalm 34:18",
    "“He strengthens the fainthearted.” — Psalm 138:3",
    "“God is our refuge and fortress.” — Psalm 91:2",
    "“He works all things for good.” — Romans 8:28",
    "“The Lord is gracious and full of compassion.” — Psalm 145:8",
    "“He will bless you abundantly.” — Deuteronomy 28:2",
    "“The Lord gives wisdom and understanding.” — Proverbs 2:6",
    "“He renews your mind.” — Romans 12:2",
    "“The Lord will keep you in peace.” — Isaiah 26:3",
    "“He is faithful to complete His work in you.” — Philippians 1:6",
    "“The Lord is my shepherd.” — Psalm 23:1"
  ];

  String todayVerse = "";

  @override
  void initState() {
    super.initState();
    loadVerse();
  }

  void loadVerse() {
    int dayNumber = DateTime.now().day % verses.length;
    setState(() {
      todayVerse = verses[dayNumber];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff12efdd),
      appBar: AppBar(
        title: Text("📖 Daily Bible", style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: Container(
          height: 206,
          margin: EdgeInsets.all(20),
          padding: EdgeInsets.all(21),
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [Colors.pink, Colors.orange, Colors.purple]),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            todayVerse,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 27, fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      ),
    );
  }
}

/*---------------------------------------------------
                DAILY CHECK-IN PAGE
---------------------------------------------------*/
class CheckInPage extends StatefulWidget {
  @override
  _CheckInPageState createState() => _CheckInPageState();
}

class _CheckInPageState extends State<CheckInPage> {
  final TextEditingController nameCtrl = TextEditingController();
  final TextEditingController titleCtrl = TextEditingController();
  final TextEditingController msgCtrl = TextEditingController();

  final CollectionReference notifications =
      FirebaseFirestore.instance.collection('notification');

  /// ================= LOCAL DELETE LOGIC =================

  Future<Set<String>> _getHiddenIds() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('hidden_notifications')?.toSet() ?? {};
  }

  Future<void> _hideNotification(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final hidden = prefs.getStringList('hidden_notifications') ?? [];
    hidden.add(id);
    await prefs.setStringList('hidden_notifications', hidden);
  }

  /// ================= SUBMIT =================

  Future<void> submitNotification() async {
    if (nameCtrl.text.isEmpty ||
        titleCtrl.text.isEmpty ||
        msgCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("⚠️ Please fill all fields")),
      );
      return;
    }

    await notifications.add({
      "name": nameCtrl.text.trim(),
      "title": titleCtrl.text.trim(),
      "message": msgCtrl.text.trim(),
      "time": Timestamp.now(),
    });

    nameCtrl.clear();
    titleCtrl.clear();
    msgCtrl.clear();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("✅ Notification submitted")),
    );
  }

  /// ================= UI =================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("🔔 Notifications"),
        backgroundColor: Colors.indigo,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xff6a1b9a), Color(0xff283593)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(12),
              child: Column(
                children: [
                  _field(nameCtrl, "Your Name 👤"),
                  _field(titleCtrl, "Notification Title ✨"),
                  _field(msgCtrl, "Message 🔔", lines: 3),
                  SizedBox(height: 10),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      shape: StadiumBorder(),
                    ),
                    onPressed: submitNotification,
                    icon: Icon(Icons.send),
                    label: Text("Submit Notification"),
                  ),
                ],
              ),
            ),
            Divider(color: Colors.white),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream:
                    notifications.orderBy("time", descending: true).snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }

                  return FutureBuilder<Set<String>>(
                    future: _getHiddenIds(),
                    builder: (context, hiddenSnapshot) {
                      if (!hiddenSnapshot.hasData) {
                        return SizedBox();
                      }

                      final hiddenIds = hiddenSnapshot.data!;
                      final docs = snapshot.data!.docs
                          .where((doc) => !hiddenIds.contains(doc.id))
                          .toList();

                      if (docs.isEmpty) {
                        return Center(
                          child: Text(
                            "No Notifications 🔕",
                            style: TextStyle(color: Colors.white),
                          ),
                        );
                      }

                      return ListView(
                        children: docs.map((doc) {
                          return Card(
                            elevation: 6,
                            margin: EdgeInsets.all(8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: ListTile(
                              title: Text("✨ ${doc['title']}"),
                              subtitle: Text(doc['message']),
                              trailing: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text("👤 ${doc['name']}"),
                                  IconButton(
                                    icon: Icon(Icons.delete, color: Colors.red),
                                    onPressed: () async {
                                      await _hideNotification(doc.id);
                                      setState(() {});
                                    },
                                  ),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String hint,
      {int lines = 1}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: controller,
        maxLines: lines,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}

/* prayer request---------*/
class PrayerRequestPage extends StatefulWidget {
  @override
  _PrayerRequestPageState createState() => _PrayerRequestPageState();
}

class _PrayerRequestPageState extends State<PrayerRequestPage> {
  final TextEditingController nameCtrl = TextEditingController();
  final TextEditingController titleCtrl = TextEditingController();
  final TextEditingController msgCtrl = TextEditingController();

  final CollectionReference prayers =
      FirebaseFirestore.instance.collection('prayers');

  /// 🔹 LOCAL hidden prayers (THIS DEVICE ONLY)
  Set<String> hiddenPrayerIds = {};

  /// 🔹 Load hidden prayer IDs (persistent)
  Future<void> _loadHiddenPrayers() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      hiddenPrayerIds = prefs.getStringList('hidden_prayers')?.toSet() ?? {};
    });
  }

  /// 🔹 Save hidden prayer ID
  Future<void> _hidePrayer(String id) async {
    final prefs = await SharedPreferences.getInstance();
    hiddenPrayerIds.add(id);
    await prefs.setStringList('hidden_prayers', hiddenPrayerIds.toList());
  }

  @override
  void initState() {
    super.initState();
    _loadHiddenPrayers();
  }

  void submitPrayer() async {
    if (nameCtrl.text.isEmpty || titleCtrl.text.isEmpty || msgCtrl.text.isEmpty)
      return;

    await prayers.add({
      "name": nameCtrl.text.trim(),
      "title": titleCtrl.text.trim(),
      "message": msgCtrl.text.trim(),
      "time": Timestamp.now(),
    });

    nameCtrl.clear();
    titleCtrl.clear();
    msgCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff6a1b9a),
      appBar: AppBar(
        title: Text("🙏 Prayer Request"),
        backgroundColor: darkBlue,
      ),
      body: Column(
        children: [
          // ✍️ Input Area
          Padding(
            padding: EdgeInsets.all(12),
            child: Column(
              children: [
                _field(nameCtrl, "Your Name 👤"),
                _field(titleCtrl, "Prayer Title ✨"),
                _field(msgCtrl, "Prayer Request 🙏", lines: 3),
                SizedBox(height: 8),
                ElevatedButton.icon(
                  onPressed: submitPrayer,
                  icon: Icon(Icons.send),
                  label: Text("Submit Prayer"),
                )
              ],
            ),
          ),

          Divider(color: Colors.white),

          // 📖 Prayer Wall
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: prayers.orderBy("time", descending: true).snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) {
                  return Center(child: CircularProgressIndicator());
                }

                final docs = snap.data!.docs
                    .where((doc) => !hiddenPrayerIds.contains(doc.id))
                    .toList();

                if (docs.isEmpty) {
                  return Center(
                    child: Text(
                      "No prayers to show 🙏",
                      style: TextStyle(color: Colors.white),
                    ),
                  );
                }

                return ListView(
                  children: docs.map((doc) {
                    return Card(
                      elevation: 5,
                      margin: EdgeInsets.all(8),
                      child: ListTile(
                        title: Text("✨ ${doc['title']}"),
                        subtitle: Text(doc['message']),
                        trailing: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text("👤 ${doc['name']}"),
                            IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () async {
                                await _hidePrayer(doc.id);
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String hint, {int lines = 1}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: c,
        maxLines: lines,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }
}

/*---------------------------------------------------
                OTHER PAGES
---------------------------------------------------*/

class AboutUsPage extends StatelessWidget {
  void openWebsite() async {
    final url = Uri.parse("https://www-pottershousetrichy-com.netlify.app/");
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw "Could not open the website";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ℹ️ About Us", style: TextStyle(color: Colors.white)),
        backgroundColor: darkBlue,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ---------- TEXT ----------
            Text(
              "📖 Potter's House Church\n\n"
              " 🎯The Potter’s House Christian Fellowship is a worldwide movement "
              "with over 4,500 churches across the globe. Our mission is to make "
              "disciples of Jesus Christ, reaching communities through evangelism, "
              "church planting, and the transformative power of the Gospel."
              "We are committed to building strong families, restoring lives, "
              "and spreading the message of hope to every nation.\n\n"
              " 🌐scan the QR code for Church Website below ",
              style: TextStyle(
                fontSize: 18,
                color: darkBlue,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 25),

            // ---------- QR IMAGE ----------
            Center(
              child: Image.asset(
                "assets/images/map.jpg",
                height: 200,
                width: 200,
                fit: BoxFit.cover,
              ),
            ),

            SizedBox(height: 25),

            // ---------- OPEN LINK BUTTON ----------
            Center(
              child: ElevatedButton(
                onPressed: openWebsite,
                style: ElevatedButton.styleFrom(
                  backgroundColor: darkBlue,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                ),
                child: Text(
                  "📍 click website Link",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  final Color darkBlue = Color(0xFF003366);

  // --- OPEN LINK FUNCTION ---
  void openChurchWebsite() async {
    final url = Uri.parse("https://maps.app.goo.gl/wPAzP915VtCY4GKq6?g_st=aw");
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw "Could not open the website";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: darkBlue,
        title: Text(
          "📞 Contact Us",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              " ✨Pastor: Martin Jeyaraj\n\n"
              " 📞Phone: 9842466433\n\n"
              " 📍Address: RPK Hardware Upstairs, Sunday Nagar, Near Indian Bank, KK Nagar, Trichy - 620021\n\n"
              "🗺️scan the map QR code below",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: darkBlue,
              ),
            ),

            SizedBox(height: 20),

            // ------ QR IMAGE ------
            Center(
              child: Image.asset(
                "assets/images/loca.jpg",
                height: 200,
                width: 200,
                fit: BoxFit.cover,
              ),
            ),

            SizedBox(height: 25),

            // ------ OPEN LINK BUTTON ------
            Center(
              child: ElevatedButton(
                onPressed: openChurchWebsite,
                style: ElevatedButton.styleFrom(
                  backgroundColor: darkBlue,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                ),
                child: Text(
                  "📍 Click map Link",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MinistryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("👥 Church Ministries",
              style: TextStyle(color: Colors.white))),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            ministryCard("(Sunday Morning)🕒Time : 9:30 AM to 12:15 PM",
                "assets/images/sunday mo.jpg"),
            ministryCard("(sunday Evening)🕒Time : 5:30 PM to 7:00 PM",
                "assets/images/sunday ev.jpg"),
            ministryCard("(Wednesday Evening)🕒Time : 6:30 PM to 8:30 PM",
                "assets/images/wednesday.jpg"),
            ministryCard("(House Visting,Monday)🕒 Time : 7:00 PM to 8:30 PM",
                "assets/images/house.jpg"),
            ministryCard(
                "Early Morning Prayer : First week Tuesday Morning 🕒5:00 AM to 6:00 AM.",
                "assets/images/early.jpg"),
            ministryCard(
                "Women's Online Prayer : Early Morning 🕒5:30 AM Every day",
                "assets/images/womens.jpg"),
            ministryCard(
                "Women's  Prayer : Every Second and Last Weak 🕒7:30 PM to 8:30 PM",
                "assets/images/women.jpg"),
            ministryCard(
                "Men's Online Prayer : Every Month Last week Friday 🕒 7:30 PM to 8:30 PM",
                "assets/images/men.jpg"),
            ministryCard(
                "Night Prayer : Every Month First Week Friday Night 🕒 9:30 PM to 10:30 PM (In Church)",
                "assets/images/night.jpg"),
            ministryCard(
                "Fasting Prayer : Every Week Saturday 🕒 11:00 AM to 12:00 PM (In church)",
                "assets/images/fasting.jpg"),
            ministryCard("(outreach saturday) 🕒Time : 7:00 PM to 8:00 PM",
                "assets/images/outreach.jpg"),
            ministryCard("Daily Prayer -🕒 9 AM to 10 AM (In church)",
                "assets/images/daily.jpg"),
          ],
        ),
      ),
    );
  }

  Widget ministryCard(String title, String img) {
    return Card(
      margin: EdgeInsets.only(bottom: 20),
      elevation: 5,
      child: Column(
        children: [
          Image.asset(img, height: 180, fit: BoxFit.cover),
          Padding(
            padding: EdgeInsets.all(10),
            child: Text(title,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: darkBlue)),
          )
        ],
      ),
    );
  }
}

class ChurchImages extends StatefulWidget {
  @override
  _ChurchImagesState createState() => _ChurchImagesState();
}

class _ChurchImagesState extends State<ChurchImages> {
  final CollectionReference imagesRef =
      FirebaseFirestore.instance.collection('church-images');

  final TextEditingController passwordCtrl = TextEditingController();
  bool _authenticated = false;
  final String _correctPassword = "potters@123";

  void _checkPassword() {
    if (passwordCtrl.text == _correctPassword) {
      setState(() => _authenticated = true);
      Navigator.pop(context);
    }
  }

  void _showPasswordDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Admin Login"),
        content: TextField(
          controller: passwordCtrl,
          obscureText: true,
          decoration: InputDecoration(labelText: "Password"),
        ),
        actions: [
          ElevatedButton(onPressed: _checkPassword, child: Text("Login")),
        ],
      ),
    );
  }

  Future<void> _uploadImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    File file = File(picked.path);
    String name = DateTime.now().millisecondsSinceEpoch.toString();

    final ref = FirebaseStorage.instance.ref('church-images/$name');
    await ref.putFile(file);
    String url = await ref.getDownloadURL();

    await imagesRef.add({
      'url': url,
      'title': 'Church Image',
      'description': 'Uploaded by Admin',
      'uploaded_at': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _deleteImage(String id, String url) async {
    await FirebaseStorage.instance.refFromURL(url).delete();
    await imagesRef.doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("📷 Church Images"),
        actions: [
          IconButton(
              icon: Icon(Icons.admin_panel_settings),
              onPressed: _showPasswordDialog),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: imagesRef.orderBy('uploaded_at', descending: true).snapshots(),
        builder: (c, s) {
          if (!s.hasData) return Center(child: CircularProgressIndicator());
          return ListView(
            children: s.data!.docs.map((doc) {
              final d = doc.data() as Map<String, dynamic>;
              return Card(
                child: Stack(
                  children: [
                    Image.network(d['url'], height: 200, fit: BoxFit.cover),
                    if (_authenticated)
                      Positioned(
                        right: 10,
                        top: 10,
                        child: IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteImage(doc.id, d['url']),
                        ),
                      ),
                  ],
                ),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: _authenticated
          ? FloatingActionButton(
              onPressed: _uploadImage, child: Icon(Icons.add))
          : null,
    );
  }
}

class SpecialEvents extends StatefulWidget {
  @override
  _SpecialEventsState createState() => _SpecialEventsState();
}

class _SpecialEventsState extends State<SpecialEvents>
    with SingleTickerProviderStateMixin {
  final CollectionReference eventsRef =
      FirebaseFirestore.instance.collection('special-events');

  final TextEditingController passwordCtrl = TextEditingController();
  bool _authenticated = false;
  final String _correctPassword = "potters@123";

  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 800))
          ..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _checkPassword() {
    if (passwordCtrl.text == _correctPassword) {
      setState(() => _authenticated = true);
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Incorrect password")),
      );
      passwordCtrl.clear();
    }
  }

  void _showPasswordDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Admin Login"),
        content: TextField(
          controller: passwordCtrl,
          obscureText: true,
          decoration: InputDecoration(labelText: "Password"),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: Text("Cancel")),
          ElevatedButton(onPressed: _checkPassword, child: Text("Login")),
        ],
      ),
    );
  }

  Future<void> _uploadEvent() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    File file = File(picked.path);
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();

    String title = '', description = '';
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Event Details"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
                onChanged: (v) => title = v,
                decoration: InputDecoration(labelText: "Title")),
            TextField(
                onChanged: (v) => description = v,
                decoration: InputDecoration(labelText: "Description")),
          ],
        ),
        actions: [
          ElevatedButton(
              onPressed: () => Navigator.pop(context), child: Text("Save")),
        ],
      ),
    );

    final ref = FirebaseStorage.instance.ref('special-events/$fileName');
    await ref.putFile(file);
    String url = await ref.getDownloadURL();

    await eventsRef.add({
      'url': url,
      'title': title.isEmpty ? 'New Event' : title,
      'description': description.isEmpty ? 'Uploaded by Admin' : description,
      'uploaded_at': FieldValue.serverTimestamp(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("✅ Event Uploaded")),
    );
  }

  Future<void> _deleteEvent(String id, String url) async {
    await FirebaseStorage.instance.refFromURL(url).delete();
    await eventsRef.doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("🎉 Special Events"),
        backgroundColor: Colors.pink,
        actions: [
          IconButton(
              icon: Icon(Icons.admin_panel_settings),
              onPressed: _showPasswordDialog),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: eventsRef.orderBy('uploaded_at', descending: true).snapshots(),
        builder: (c, s) {
          if (!s.hasData) return Center(child: CircularProgressIndicator());
          if (s.data!.docs.isEmpty) return Center(child: Text("No Events"));

          return ListView(
            children: s.data!.docs.map((doc) {
              final d = doc.data() as Map<String, dynamic>;
              return Card(
                margin: EdgeInsets.all(10),
                child: Column(
                  children: [
                    Image.network(d['url'], height: 200, fit: BoxFit.cover),
                    ListTile(
                      title: Text(d['title']),
                      subtitle: Text(d['description']),
                      trailing: _authenticated
                          ? IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _deleteEvent(doc.id, d['url']),
                            )
                          : null,
                    )
                  ],
                ),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: _authenticated
          ? FloatingActionButton(
              onPressed: _uploadEvent,
              child: Icon(Icons.add),
              backgroundColor: Colors.pink,
            )
          : null,
    );
  }
}
